# MD•APP — prototype

A deliberately tiny Markdown-native application framework.

## Run

```bash
python3 app.py
```

Then open http://127.0.0.1:8000

## Structure

- `pages/` — routes/pages
- `modules/` — reusable snippets/modules
- `data/` — future data sources
- `framework.md` — tiny framework contract
- `app.py` — runtime

## Prototype DSL

```md
@stats
label: Revenue
value: €82,400
change: +12%
@end
```

Adding a new module is just adding `modules/name.md`.
Adding a new page is just adding `pages/name.md`.

This prototype intentionally avoids React, build tooling, a database and a large component framework.
