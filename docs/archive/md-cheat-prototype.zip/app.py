from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
from pathlib import Path
import html, re, json

ROOT = Path(__file__).parent
PAGES = ROOT / "pages"
MODULES = ROOT / "modules"
DATA = ROOT / "data"

def frontmatter(src):
    meta = {}
    if src.startswith("---"):
        parts = src.split("---", 2)
        if len(parts) == 3:
            for line in parts[1].strip().splitlines():
                if ":" in line:
                    k, v = line.split(":", 1)
                    meta[k.strip()] = v.strip().strip('"\'')
            src = parts[2].lstrip()
    return meta, src

def inline(s):
    s = html.escape(s)
    s = re.sub(r"\*\*(.+?)\*\*", r"<strong>\1</strong>", s)
    s = re.sub(r"`(.+?)`", r"<code>\1</code>", s)
    return s

def module(name, body):
    p = MODULES / f"{name}.md"
    if not p.exists():
        return f'<div class="missing">Unknown module: {html.escape(name)}</div>'
    meta, tpl = frontmatter(p.read_text())
    props = {}
    for line in body.strip().splitlines():
        if ":" in line:
            k, v = line.split(":", 1)
            props[k.strip()] = v.strip()
    for k, v in props.items():
        tpl = tpl.replace("{{ " + k + " }}", html.escape(v))
        tpl = tpl.replace("{{" + k + "}}", html.escape(v))
    return render(tpl)

def render(src):
    out, paragraph = [], []
    def flush():
        if paragraph:
            out.append("<p>" + "<br>".join(paragraph) + "</p>")
            paragraph.clear()

    lines = src.splitlines()
    i = 0
    while i < len(lines):
        line = lines[i]
        if line.startswith("@") and not line.startswith("@end"):
            m = re.match(r"@([\w-]+)(?:\s+(.*))?$", line.strip())
            if m:
                name, rest = m.group(1), m.group(2) or ""
                body = []
                if rest and "=" in rest:
                    for pair in re.findall(r'(\w+)=("[^"]*"|\S+)', rest):
                        body.append(f"{pair[0]}: {pair[1].strip(chr(34))}")
                i += 1
                while i < len(lines) and lines[i].strip() != "@end":
                    body.append(lines[i])
                    i += 1
                flush()
                out.append(module(name, "\n".join(body)))
                i += 1
                continue
        if line.startswith("# "):
            flush(); out.append(f"<h1>{inline(line[2:])}</h1>")
        elif line.startswith("## "):
            flush(); out.append(f"<h2>{inline(line[3:])}</h2>")
        elif line.startswith("### "):
            flush(); out.append(f"<h3>{inline(line[4:])}</h3>")
        elif line.strip() == "":
            flush()
        elif line.startswith("- "):
            if not out or not out[-1].startswith("<ul>"):
                flush(); out.append("<ul>")
            out.append(f"<li>{inline(line[2:])}</li>")
        else:
            paragraph.append(inline(line))
        i += 1
    flush()
    if out and out[-1] == "<ul>": out[-1] = "</ul>"
    return "\n".join(out)

def page(path):
    file = PAGES / (path.strip("/") or "index") 
    file = file.with_suffix(".md")
    if not file.exists():
        return "<h1>404</h1><p>Page not found.</p>", 404
    meta, src = frontmatter(file.read_text())
    nav = []
    for p in sorted(PAGES.glob("*.md")):
        m, _ = frontmatter(p.read_text())
        nav.append(f'<a href="/{"" if p.stem=="index" else p.stem}">{html.escape(m.get("title", p.stem.title()))}</a>')
    shell = f"""<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width">
<title>{html.escape(meta.get("title","MD App"))}</title><link rel="stylesheet" href="/static/style.css"></head>
<body><aside><strong>MD•APP</strong>{''.join(nav)}</aside><main>{render(src)}</main></body></html>"""
    return shell, 200

class Handler(BaseHTTPRequestHandler):
    def do_GET(self):
        if self.path.startswith("/static/"):
            f = ROOT / self.path.lstrip("/")
            if f.exists():
                self.send_response(200); self.send_header("Content-Type","text/css"); self.end_headers(); self.wfile.write(f.read_bytes()); return
        content, status = page(self.path.split("?")[0])
        self.send_response(status); self.send_header("Content-Type","text/html; charset=utf-8"); self.end_headers(); self.wfile.write(content.encode())

if __name__ == "__main__":
    print("MD•APP → http://127.0.0.1:8000")
    ThreadingHTTPServer(("127.0.0.1", 8000), Handler).serve_forever()
