---
title: Dashboard
---

# Dashboard

@stats
label: Revenue
value: €82,400
change: +12%
@end

@card
title: Projects
text: "12 active projects. This card is a reusable module."
@end

## Composition

Modules can be nested conceptually and overridden with tiny property blocks.
