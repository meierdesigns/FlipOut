---
title: Home
---

# MD•APP

A tiny Markdown-native application runtime.

@hero
title: "Build with text"
text: "Pages, modules and UI composition live in simple MD files."
@end

## Try it

- Open `pages/dashboard.md`
- Change some text
- Add a module in `modules/`
- Refresh the browser
