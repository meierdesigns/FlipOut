# MD•APP Framework

## Pages
`pages/*.md` automatically become routes.

## Modules
`modules/*.md` automatically become reusable UI snippets.

## Module syntax

@module
key: value
@end

## Philosophy
Keep application logic in the runtime and application content/composition in MD.
